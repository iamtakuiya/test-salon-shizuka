import { useState, useRef, useEffect } from "react";
import "./styles.css";
import { SERVICES } from "./constants";

export default function App() {
  const [activeTabIdx, setActiveTabIdx] = useState(0);

  // Track Styles for the moving underline
  const [sliderStyle, setSliderStyle] = useState({ left: 0, width: 0 });

  const tabsContainerRef = useRef(null);
  // An array of references for each tab button
  const tabsRef = useRef([]);

  const halfLength = Math.ceil(SERVICES.menu.length / 2);
  const leftColumnData = SERVICES.menu.slice(0, halfLength);
  const rightColumnData = SERVICES.menu.slice(halfLength);

  useEffect(() => {
    const activeTabEl = tabsRef.current[activeTabIdx];
    const containerEl = tabsContainerRef.current;

    if (activeTabEl && containerEl) {
      // Use requestAnimationFrame to ensure style calculations are accurate after DOM repaint
      requestAnimationFrame(() => {
        setSliderStyle({
          left: activeTabEl.offsetLeft,
          width: activeTabEl.clientWidth,
        });

        const containerWidth = containerEl.clientWidth;
        const tabOffsetLeft = activeTabEl.offsetLeft;
        const tabWidth = activeTabEl.clientWidth;

        // Calculate center position target
        const targetScrollLeft =
          tabOffsetLeft - containerWidth / 2 + tabWidth / 2;

        containerEl.scrollTo({
          left: targetScrollLeft,
          behavior: "smooth",
        });
      });
    }
  }, [activeTabIdx]);

  const formatPrice = (item) => {
    let priceStr = `¥${item.price.toLocaleString()}`;
    if (item.is_additional_fee) priceStr = `+${priceStr}`;
    if (item.is_starting_price) priceStr = `${priceStr}〜`;
    return priceStr;
  };

  // Reusable Category Card component to keep rendering uniform
  const CategoryCard = ({ category, catIdx, columnId }) => (
    <article
      // Dynamic Class: Add a helper class to show/hide based on active mobile tab
      className={`menu__item ${
        activeTabIdx === catIdx
          ? "menu__item--activeMobile"
          : "menu__item--hiddenMobile"
      }`}
    >
      {/* Category Header */}
      <header className="menu__titleContainer">
        <div className="menu__categoryWrapper">
          <h3 className="menu__title">{category.category}</h3>
          {category.includes && (
            <span className="menu__subname">［{category.includes}］</span>
          )}
        </div>
        {category.category_description && (
          <p className="menu__submenu">{category.category_description}</p>
        )}
      </header>

      {/* Items Map */}
      {category.items.map((item, itemIdx) => (
        <div className="menu__content" key={`${columnId}-item-${itemIdx}`}>
          <div className="menu__row">
            <div className="menu__rowLeft">
              <span className="menu__name">{item.name}</span>
              {item.includes && (
                <span className="menu__subname">[{item.includes}]</span>
              )}
            </div>
            <div className="menu__rowRight">
              <p className="menu__price">{formatPrice(item)}</p>
            </div>
          </div>

          {item.description && (
            <div className="menu__note">
              <p>{item.description}</p>
            </div>
          )}
        </div>
      ))}

      {category.notes && (
        <div className="menu__box">
          <p className="menu__optionalDesc">＊{category.notes}</p>
        </div>
      )}
    </article>
  );

  return (
    <>
      <section id="menu" className="menu">
        <header className="menu__headline">
          <h2 className="menu__heading">Menu</h2>
          <div className="menu__subheadingWrapper">
            <span className="menu__subheading">
              カウンセリングをもとに、あなたの骨格、髪質
            </span>
            <span className="menu__subheading">
              日々のライフスタイルに寄り添った施術をご提案いたします
            </span>
          </div>
        </header>

        <div className="menu__container">
          {/* Tab Navigation: Tabs for mobile layout */}
          <div className="menu__tabsWrapper">
            <div ref={tabsContainerRef} className="menu__tabs">
              {SERVICES.menu.map((cat, idx) => (
                <button
                  key={`tab-${idx}`}
                  ref={(el) => (tabsRef.current[idx] = el)}
                  role="tab"
                  className={`
                    menu__tab 
                    ${activeTabIdx === idx ? "menu__tab--active" : ""}
                  `}
                  onClick={() => setActiveTabIdx(idx)}
                >
                  {cat.category}
                </button>
              ))}
              <div className="menu__tabSlider" style={sliderStyle} />
            </div>
          </div>

          {/* Main Menus Container */}
          <div className="menu__listContainer">
            {/* Left Column (First 1/2 of data) */}
            <div className="menu__list">
              {leftColumnData.map((category, idx) => (
                <CategoryCard
                  key={`left-${idx}`}
                  category={category}
                  catIdx={idx} // Indices 1, 2, 3
                  columnId="left"
                />
              ))}
            </div>

            {/* Vertical Divider */}
            <div className="divider-v"></div>

            {/* Right Column (Second 1/2 of data) */}
            <div className="menu__list">
              {rightColumnData.map((category, idx) => (
                <CategoryCard
                  key={`right-${idx}`}
                  category={category}
                  catIdx={idx + halfLength} // Indices 3, 4, 5
                  columnId="right"
                />
              ))}
            </div>
          </div>

          {/* Footnotes Section */}
          <div className="menu__footNoteContainer">
            {SERVICES.footer_notes.map((note, idx) => (
              <p className="menu__footNote" key={`footnote-${idx}`}>
                {note}
              </p>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
